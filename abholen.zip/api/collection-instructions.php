<?php
/**
 * Fetches available pickup dates and places for a validated address,
 * using the houseKey returned by validate-address.php.
 *
 * GET params: house_key (required)
 * Response: { "dates": ["2026-09-15", ...], "places": [{ "name": "...", "label": "..." }, ...] }
 *
 * NOTE: the exact shape of Swiss Post's collection-instructions
 * response isn't nailed down from the reference code (it just passed
 * the raw response through). The parsing below is written to be
 * tolerant of a couple of likely shapes — check the "raw" field in
 * the error case if dates/places come back empty and adjust
 * accordingly.
 */

header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/_swisspost.php';

$config = require __DIR__ . '/../config.php';
$sp = $config['swisspost'];

$houseKey = trim($_GET['house_key'] ?? '');
$lang     = $_GET['lang'] ?? 'en';

if ($houseKey === '') {
    http_response_code(400);
    echo json_encode(['dates' => [], 'places' => [], 'error' => 'missing_house_key']);
    exit;
}

$token = sp_get_token($sp, $sp['collection_scope']);
if (!$token) {
    http_response_code(502);
    echo json_encode(['dates' => [], 'places' => [], 'error' => 'auth_failed']);
    exit;
}

$url = str_replace('{houseKey}', rawurlencode($houseKey), $sp['collection_instructions_url']);
$result = sp_request($url, 'GET', null, $token);

if ($result['status'] !== 200 || !$result['data']) {
    http_response_code(502);
    echo json_encode(['dates' => [], 'places' => [], 'error' => 'instructions_unreachable']);
    exit;
}

$data = $result['data'];

$dates = [];
foreach (($data['dates'] ?? $data['possibleDates'] ?? []) as $d) {
    $dates[] = is_array($d) ? ($d['date'] ?? '') : (string) $d;
}
$dates = array_values(array_filter($dates));

$places = [];
$seen = [];
foreach (($data['places'] ?? $data['possiblePlaces'] ?? []) as $p) {
    if (!is_array($p)) {
        continue;
    }
    $name = $p['name'] ?? '';
    if ($name === '' || isset($seen[$name])) {
        continue;
    }
    $seen[$name] = true;
    $label = $p['description'][$lang] ?? $p['description']['de'] ?? $p['description']['en'] ?? $name;
    $places[] = ['name' => $name, 'label' => $label];
}

echo json_encode(['dates' => $dates, 'places' => $places]);
