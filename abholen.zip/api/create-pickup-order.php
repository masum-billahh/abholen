<?php
/**
 * Creates a Swiss Post collection/pickup order from the full wizard
 * payload, approves it, logs it to the local JSONL store, and
 * returns a summary to the front end.
 *
 * Expects a JSON POST body:
 * {
 *   first_name, last_name, company,
 *   street, house_number, zip, city, house_key,
 *   pickup_date, pickup_place, parcel_size,
 *   email, phone
 * }
 */

header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/_swisspost.php';
require __DIR__ . '/_storage.php';
require __DIR__ . '/_woo_sync.php';

$config = require __DIR__ . '/../config.php';
$sp = $config['swisspost'];

$input = json_decode(file_get_contents('php://input'), true) ?? [];

$firstName   = trim($input['first_name'] ?? '');
$lastName    = trim($input['last_name'] ?? '');
$company     = trim($input['company'] ?? '');
$street      = trim($input['street'] ?? '');
$houseNumber = trim($input['house_number'] ?? '');
$zip         = trim($input['zip'] ?? '');
$city        = trim($input['city'] ?? '');
$pickupDate  = trim($input['pickup_date'] ?? '');
$pickupPlace = trim($input['pickup_place'] ?? '');
$parcelSize  = strtoupper(trim($input['parcel_size'] ?? ''));
$email       = trim($input['email'] ?? '');
$phone       = trim($input['phone'] ?? '');
$lang        = strtoupper(trim($input['lang'] ?? 'DE'));

$required = compact('firstName', 'lastName', 'street', 'houseNumber', 'zip', 'city', 'pickupDate', 'pickupPlace', 'email', 'phone');
foreach ($required as $key => $value) {
    if ($value === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'missing_field', 'field' => $key]);
        exit;
    }
}

if (!in_array($parcelSize, ['SMALL', 'MEDIUM', 'LARGE'], true)) {
    $parcelSize = 'LARGE';
}
if (!in_array($lang, ['DE', 'FR', 'EN', 'IT'], true)) {
    $lang = 'DE';
}

$token = sp_get_token($sp, $sp['collection_scope']);
if (!$token) {
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => 'auth_failed']);
    exit;
}

$reference = 'AF-' . date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6);

$pickupData = [
    'collection' => [
        'place'      => $pickupPlace,
        'date'       => $pickupDate,
        'timeWindow' => $sp['time_window'],
    ],
    'language'        => $lang,
    'mandator'        => $sp['mandator'],
    'frankingLicence' => $sp['franking_licence'],
    'contactPerson'   => trim("$firstName $lastName"),
    'domicile' => [
        'salutation'       => 'EMPTY',
        'title'            => '',
        'firstName'        => $firstName,
        'lastName'         => $lastName,
        'organisationName' => $company,
        'email'            => $email,
        'mobile'           => $phone,
        'address' => [
            'street'      => $street,
            'houseNumber' => $houseNumber,
            'postcode'    => $zip,
            'city'        => $city,
            'pobox'       => '',
            'addOn1'      => '',
            'addOn2'      => '',
        ],
    ],
    'detail' => [
        'parcel' => [
            'userProfileId' => 'string',
            'parcels' => [
                [
                    'productCode'         => $sp['product_code'],
                    'additionalServices'  => ['EMPTY'],
                    'physicalProperties'  => [
                        'size'             => $parcelSize,
                        'weightUpperBound' => 30000, // 30 kg max (incl. ~5 kg box weight)
                    ],
                    'labelProvided'       => 1,
                    'recipientReference'  => $reference,
                ],
            ],
        ],
    ],
];

$createResult = sp_request($sp['create_order_url'], 'POST', $pickupData, $token);

if (!in_array($createResult['status'], [200, 201], true) || empty($createResult['data']['orderKey'])) {
    echo json_encode([
        'success' => false,
        'message' => 'create_failed',
        'detail'  => $createResult['raw'],
    ]);
    exit;
}

$orderKey = $createResult['data']['orderKey'];

// Small delay before approval, mirroring the working WooCommerce integration.
sleep(1);

$approveUrl = str_replace('{orderKey}', rawurlencode($orderKey), $sp['approve_order_url']);
$approveResult = sp_request($approveUrl, 'POST', null, $token);

if (!in_array($approveResult['status'], [200, 201], true)) {
    sp_log_pickup_order([
        'reference'   => $reference,
        'status'      => 'created_not_approved',
        'order_key'   => $orderKey,
        'first_name'  => $firstName,
        'last_name'   => $lastName,
        'company'     => $company,
        'email'       => $email,
        'phone'       => $phone,
        'address'     => "$street $houseNumber, $zip $city",
        'pickup_date' => $pickupDate,
        'pickup_place' => $pickupPlace,
        'parcel_size' => $parcelSize,
    ]);

    echo json_encode([
        'success' => false,
        'message' => 'approval_failed',
        'orderKey' => $orderKey,
        'detail'  => $approveResult['raw'],
    ]);
    exit;
}

$mailpieceId = $createResult['data']['detail']['parcel']['parcels'][0]['identifier']['mailpieceId'] ?? null;
$parcelKey   = $createResult['data']['detail']['parcel']['parcels'][0]['identifier']['parcelKey'] ?? null;
$trackingUrl = $mailpieceId ? "https://service.post.ch/ekp-web/external/view/{$mailpieceId}?lang=" . strtolower($lang) : null;

sp_log_pickup_order([
    'reference'    => $reference,
    'status'       => $createResult['data']['state'] ?? 'created',
    'order_key'    => $orderKey,
    'order_id'     => $createResult['data']['orderId'] ?? null,
    'mailpiece_id' => $mailpieceId,
    'parcel_key'   => $parcelKey,
    'tracking_url' => $trackingUrl,
    'first_name'   => $firstName,
    'last_name'    => $lastName,
    'company'      => $company,
    'email'        => $email,
    'phone'        => $phone,
    'address'      => "$street $houseNumber, $zip $city",
    'pickup_date'  => $pickupDate,
    'pickup_place' => $pickupPlace,
    'parcel_size'  => $parcelSize,
]);

if ($trackingUrl && !empty($config['woocommerce_sync'])) {
    sp_sync_tracking_to_woocommerce($config['woocommerce_sync'], [
        'email'        => $email,
        'tracking_url' => $trackingUrl,
        'reference'    => $reference,
        'mailpiece_id' => $mailpieceId,
        'parcel_key'   => $parcelKey,
    ]);
}

echo json_encode([
    'success'      => true,
    'reference'    => $reference,
    'orderKey'     => $orderKey,
    'trackingUrl'  => $trackingUrl,
]);
