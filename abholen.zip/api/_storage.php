<?php
/**
 * Very small local log of created pickup orders, so Masum can review
 * submissions without needing a full database. Stored as JSON Lines
 * (one JSON object per line) in data/pickup-orders.jsonl.
 */

define('SP_DATA_DIR', __DIR__ . '/data');
define('SP_LOG_FILE', SP_DATA_DIR . '/pickup-orders.jsonl');

function sp_log_pickup_order(array $record): void
{
    if (!is_dir(SP_DATA_DIR)) {
        mkdir(SP_DATA_DIR, 0755, true);
    }
    $record['logged_at'] = date('c');
    file_put_contents(SP_LOG_FILE, json_encode($record) . "\n", FILE_APPEND | LOCK_EX);
}

/**
 * @return array<int, array> newest first
 */
function sp_read_pickup_orders(): array
{
    if (!is_readable(SP_LOG_FILE)) {
        return [];
    }
    $lines = file(SP_LOG_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $records = array_map(fn($line) => json_decode($line, true), $lines);
    return array_reverse($records);
}

/**
 * Merges $updates into the record matching $reference and rewrites
 * the log file. Returns true if a matching record was found.
 */
function sp_update_pickup_order(string $reference, array $updates): bool
{
    if (!is_readable(SP_LOG_FILE)) {
        return false;
    }
    $lines = file(SP_LOG_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $found = false;
    $out = [];
    foreach ($lines as $line) {
        $record = json_decode($line, true);
        if (($record['reference'] ?? null) === $reference) {
            $record = array_merge($record, $updates);
            $found = true;
        }
        $out[] = json_encode($record);
    }
    if ($found) {
        file_put_contents(SP_LOG_FILE, implode("\n", $out) . "\n", LOCK_EX);
    }
    return $found;
}