<?php
/**
 * Fire-and-forget sync of Swiss Post tracking info to the WooCommerce
 * site (repan.ch). This must never block or fail the customer-facing
 * pickup order response — errors are only written to the PHP error log.
 *
 * Pairs with the `swisspost-wizard/v1/tracking` REST route added on
 * the WooCommerce side (see repan-ch-swisspost-wizard-sync.php).
 */

function sp_sync_tracking_to_woocommerce(array $config, array $data): void
{
    if (empty($config['enabled']) || empty($config['endpoint']) || empty($config['api_key'])) {
        return;
    }

    $payload = json_encode([
        'email'        => $data['email'] ?? '',
        'tracking_url' => $data['tracking_url'] ?? '',
        'reference'    => $data['reference'] ?? '',
        'mailpiece_id' => $data['mailpiece_id'] ?? '',
        'parcel_key'   => $data['parcel_key'] ?? '',
    ]);

    $ch = curl_init($config['endpoint']);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'X-API-Key: ' . $config['api_key'],
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,      // short — don't hold up the customer's response
        CURLOPT_CONNECTTIMEOUT => 3,
    ]);

    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch) || $status >= 400) {
        error_log(sprintf(
            'Swiss Post wizard -> WooCommerce sync failed (status %s): %s | curl error: %s',
            $status,
            $response,
            curl_error($ch)
        ));
    }

    curl_close($ch);
}

/**
 * Tells the WooCommerce site a pickup was cancelled, so it can fire the
 * `swiss_post_pickup_cancelled` action (WC_Email handles the customer
 * email from there). Looked up by wizard reference, not email — the
 * WP side already tagged the order with `_swiss_post_wizard_reference`
 * when the tracking sync happened.
 */
function sp_sync_cancellation_to_woocommerce(array $config, string $reference): void
{
    if (empty($config['enabled']) || empty($config['cancel_endpoint']) || empty($config['api_key'])) {
        return;
    }

    $payload = json_encode(['reference' => $reference]);

    $ch = curl_init($config['cancel_endpoint']);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'X-API-Key: ' . $config['api_key'],
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_CONNECTTIMEOUT => 3,
    ]);

    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch) || $status >= 400) {
        error_log(sprintf(
            'Swiss Post wizard -> WooCommerce cancellation sync failed (status %s): %s | curl error: %s',
            $status,
            $response,
            curl_error($ch)
        ));
    }

    curl_close($ch);
}
