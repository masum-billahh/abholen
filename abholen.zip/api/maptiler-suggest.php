<?php
/**
 * Proxies address-suggestion requests to MapTiler's geocoding API.
 * Keeps the MapTiler key server-side and normalises the response
 * into a small, front-end-friendly shape.
 *
 * GET params: q (query string, required), lang (de|en|fr, default en)
 * Response: { "suggestions": [ { label, street, house_number, zip, city, lat, lon }, ... ] }
 */

header('Content-Type: application/json; charset=utf-8');

$config = require __DIR__ . '/../config.php';
$mt = $config['maptiler'];

$query = trim($_GET['q'] ?? '');
$lang  = $_GET['lang'] ?? 'en';
if (!in_array($lang, ['de', 'en', 'fr'], true)) {
    $lang = 'en';
}

if ($query === '' || mb_strlen($query) < 3) {
    echo json_encode(['suggestions' => []]);
    exit;
}

$url = $mt['geocoding_url'] . rawurlencode($query) . '.json?' . http_build_query([
    'key'          => $mt['api_key'],
    'country'      => $mt['country'],
    'language'     => $lang,
    'limit'        => $mt['limit'],
    'autocomplete' => 'true',
    'types'        => 'address',
]);

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 6,
    CURLOPT_CONNECTTIMEOUT => 4,
]);
$response = curl_exec($ch);
$status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr || $status !== 200 || !$response) {
    http_response_code(502);
    echo json_encode(['suggestions' => [], 'error' => 'maptiler_unreachable']);
    exit;
}

$data = json_decode($response, true);
$features = $data['features'] ?? [];

$suggestions = [];
foreach ($features as $feature) {
    $props   = $feature['properties'] ?? [];
    $center  = $feature['center'] ?? [null, null];
    $context = $feature['context'] ?? [];

    $street      = $props['street'] ?? ($feature['text'] ?? '');
    $houseNumber = $props['housenumber'] ?? ($feature['address'] ?? '');
    $zip         = '';
    $city        = '';

    foreach ($context as $ctx) {
        $id = $ctx['id'] ?? '';
        if (str_starts_with($id, 'postal_code')) {
            $zip = $ctx['text'] ?? $zip;
        }
        if (str_starts_with($id, 'place') || str_starts_with($id, 'municipality')) {
            $city = $ctx['text'] ?? $city;
        }
    }

    $suggestions[] = [
        'label'        => $feature['place_name'] ?? trim("$street $houseNumber, $zip $city"),
        'street'       => $street,
        'house_number' => (string) $houseNumber,
        'zip'          => $zip,
        'city'         => $city,
        'country'      => 'CH',
        'lat'          => $center[1] ?? null,
        'lon'          => $center[0] ?? null,
    ];
}

echo json_encode(['suggestions' => $suggestions]);
