<?php
/**
 * Shared helpers for the Swiss Post DCAPI collection/order endpoints
 * (collection-instructions.php and create-pickup-order.php).
 */

function sp_get_token(array $sp, string $scope): ?string
{
    $cacheFile = sys_get_temp_dir() . '/swisspost_token_' . md5($scope) . '.json';
    if (is_readable($cacheFile)) {
        $cached = json_decode(file_get_contents($cacheFile), true);
        if (!empty($cached['expires_at']) && $cached['expires_at'] > time() + 10) {
            return $cached['access_token'];
        }
    }

    $ch = curl_init($sp['token_url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 6,
        CURLOPT_POSTFIELDS     => http_build_query([
            'grant_type'    => 'client_credentials',
            'client_id'     => $sp['client_id'],
            'client_secret' => $sp['client_secret'],
            'scope'         => $scope,
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($status !== 200 || !$response) {
        return null;
    }

    $data = json_decode($response, true);
    if (empty($data['access_token'])) {
        return null;
    }

    file_put_contents($cacheFile, json_encode([
        'access_token' => $data['access_token'],
        'expires_at'   => time() + (int) ($data['expires_in'] ?? 300),
    ]));

    return $data['access_token'];
}

/**
 * @return array{status:int, data:?array, raw:string}
 */
function sp_request(string $url, string $method, ?array $body, string $token): array
{
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ],
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = json_encode($body);
    }
    curl_setopt_array($ch, $opts);

    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'status' => $status,
        'data'   => $response ? json_decode($response, true) : null,
        'raw'    => (string) $response,
    ];
}
