<?php
/**
 * Validates a selected address against the Swiss Post DCAPI address
 * validation endpoint.
 *
 * Expects a JSON POST body:
 * { first_name, last_name, street, house_number, zip, city, country }
 *
 * Returns: { "valid": true|false, "message": "...", "houseKey": "..." }
 */

header('Content-Type: application/json; charset=utf-8');

$config = require __DIR__ . '/../config.php';
$sp = $config['swisspost'];

$input = json_decode(file_get_contents('php://input'), true) ?? [];

$firstName   = trim($input['first_name'] ?? '');
$lastName    = trim($input['last_name'] ?? '');
$street      = trim($input['street'] ?? '');
$houseNumber = trim($input['house_number'] ?? '');
$zip         = trim($input['zip'] ?? '');
$city        = trim($input['city'] ?? '');

if ($street === '' || $zip === '' || $city === '') {
    http_response_code(400);
    echo json_encode(['valid' => false, 'message' => 'incomplete_address']);
    exit;
}

function get_swisspost_token(array $sp): ?string
{
    // Simple per-request token cache via a local file, so we don't
    // hit the token endpoint on every keystroke-triggered validation.
    $cacheFile = sys_get_temp_dir() . '/swisspost_token_validate.json';
    if (is_readable($cacheFile)) {
        $cached = json_decode(file_get_contents($cacheFile), true);
        if (!empty($cached['expires_at']) && $cached['expires_at'] > time() + 10) {
            return $cached['access_token'];
        }
    }

    $ch = curl_init($sp['token_url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 6,
        CURLOPT_POSTFIELDS     => http_build_query([
            'grant_type'    => 'client_credentials',
            'client_id'     => $sp['client_id'],
            'client_secret' => $sp['client_secret'],
            'scope'         => $sp['validate_scope'],
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($status !== 200 || !$response) {
        return null;
    }

    $data = json_decode($response, true);
    if (empty($data['access_token'])) {
        return null;
    }

    file_put_contents($cacheFile, json_encode([
        'access_token' => $data['access_token'],
        'expires_at'   => time() + (int) ($data['expires_in'] ?? 300),
    ]));

    return $data['access_token'];
}

function validate_with_swisspost(array $sp, string $token, string $firstName, string $lastName, string $street, string $houseNumber, string $zip, string $city): array
{
    // Shape matches Swiss Post's DCAPI address validation endpoint —
    // nested addressee / logisticLocation / geographicLocation object.
    // Title defaults to MISTER since the form doesn't collect a
    // salutation; adjust this if you add a gender/salutation field
    // or want to switch to a company-style addressee when the
    // "company" field is filled in.
    $payload = [
        'addressee' => [
            'title'     => 'MISTER',
            'firstName' => $firstName,
            'lastName'  => $lastName,
        ],
        'logisticLocation' => [
            'postBoxNumber' => '',
        ],
        'geographicLocation' => [
            'house' => [
                'additionalAddress' => '',
                'street'            => $street,
                'houseNumber'       => $houseNumber,
            ],
            'zip' => [
                'zip'  => $zip,
                'city' => $city,
            ],
        ],
        'fullValidation' => true,
    ];

    $ch = curl_init($sp['validate_url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ],
    ]);
    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($status !== 200 || !$response) {
        return ['valid' => false, 'message' => 'validation_unreachable'];
    }

    $data = json_decode($response, true);

    $validQualities = $sp['valid_qualities'] ?? ['DOMICILE_CERTIFIED', 'CERTIFIED', 'USABLE'];
    $quality  = $data['quality'] ?? null;
    $isValid  = $quality !== null && in_array($quality, $validQualities, true);
    $houseKey = $data['address']['geographicLocation']['house']['houseKey'] ?? null;

    return [
        'valid'    => $isValid,
        'message'  => $isValid ? 'ok' : ('quality_' . strtolower((string) $quality)),
        'houseKey' => $houseKey,
    ];
}

$token = get_swisspost_token($sp);
if (!$token) {
    http_response_code(502);
    echo json_encode(['valid' => false, 'message' => 'auth_failed']);
    exit;
}

$result = validate_with_swisspost($sp, $token, $firstName, $lastName, $street, $houseNumber, $zip, $city);
echo json_encode($result);
