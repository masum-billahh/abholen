<?php
/**
 * Deletes a parcel from a Swiss Post pickup order (test/admin use).
 * Expects a JSON POST body: { reference }
 * Looks up order_key/parcel_key from the local log by reference,
 * calls the Swiss Post delete endpoint, and marks the record
 * cancelled on success.
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/_swisspost.php';
require __DIR__ . '/_storage.php';
require __DIR__ . '/_woo_sync.php';

$config = require __DIR__ . '/../config.php';
$sp = $config['swisspost'];

if (empty($_SESSION['sp_admin_ok'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'not_authenticated']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$reference = trim($input['reference'] ?? '');

if ($reference === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'missing_reference']);
    exit;
}

$record = null;
foreach (sp_read_pickup_orders() as $o) {
    if (($o['reference'] ?? null) === $reference) {
        $record = $o;
        break;
    }
}

if (!$record) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'not_found']);
    exit;
}

$orderKey  = $record['order_key'] ?? '';
$parcelKey = $record['parcel_key'] ?? '';

if ($orderKey === '' || $parcelKey === '') {
    echo json_encode(['success' => false, 'message' => 'missing_keys']);
    exit;
}

$token = sp_get_token($sp, $sp['collection_scope']);
if (!$token) {
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => 'auth_failed']);
    exit;
}

$url = "https://dcapi.apis.post.ch/delivery/collection/order/v2/orders/{$orderKey}/parcels/{$parcelKey}";
$result = sp_request($url, 'DELETE', null, $token);

if (!in_array($result['status'], [200, 204], true)) {
    echo json_encode([
        'success' => false,
        'message' => 'delete_failed',
        'detail'  => $result['raw'],
    ]);
    exit;
}

sp_update_pickup_order($reference, [
    'status'      => 'cancelled',
    'cancelled_at' => date('c'),
]);

if (!empty($config['woocommerce_sync'])) {
    sp_sync_cancellation_to_woocommerce($config['woocommerce_sync'], $reference);
}

echo json_encode(['success' => true]);